import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ServiceSettings } from './service-settings';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { MAT_DATE_LOCALE } from '@angular/material/core';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatFormFieldModule } from '@angular/material/form-field';
import { JwtHelperService, JwtModule, JwtModuleOptions } from '@auth0/angular-jwt';
import { AuthguardService } from './shared/services/auth/authguard.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { ToastrModule } from 'ngx-toastr';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';

import { MatPaginatorModule } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ConfirmationDialogService } from './shared/services/confirmation-dialog/confirmation-dialog.service';
import { RegisterComponent } from './features/register/components/register.component';
import { LoginComponent } from './features/login/components/login.component';
import { ConfirmationDialogComponent } from './shared/components/confirmation-dialog/confirmation-dialog.component';
import { DetailsButtonsComponent } from './shared/components/detailsbuttons/detailsbuttons.component';
import { ManagementCompetitionComponent } from './features/competition/components/managementcompetition/managementcompetition.component';
import { DetailsCompetitionComponent } from './features/competition/components/detailscompetition/detailscompetition.component';
import { ManagementTeamComponent } from './features/team/components/managementteam/managementteam.component';
import { DetailsTeamComponent } from './features/team/components/detailsteam/detailsteam.component';
import { ManagementButtonsComponent } from './shared/components/managementbuttons/managementbuttons.component';

export function tokenGetter() {
  return localStorage.getItem("jwt");
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ManagementTeamComponent,
    DetailsTeamComponent,
    ManagementButtonsComponent,
    ConfirmationDialogComponent,
    DetailsButtonsComponent,
    ManagementCompetitionComponent,
    DetailsCompetitionComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    MatTableModule,  
    MatFormFieldModule,
    MatListModule,
    MatMenuModule,
    FormsModule,
    MatRadioModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatCardModule,
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgIdleKeepaliveModule.forRoot(),
    ToastrModule.forRoot({
      closeButton: true
    }),
    RouterModule.forRoot([
      { path: '', component: AppComponent/*, pathMatch: 'full', canActivate: [AuthguardService], data: { roles: [Role.Administrador, Role.Cliente] }*/ },
      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterComponent },
      { path: 'managmentteam', component: ManagementTeamComponent/*, pathMatch: 'full', canActivate: [AuthguardService], data: { roles: [Role.Administrador, Role.Cliente] }*/ },
      { path: 'detailteam/:id', component: DetailsTeamComponent/*, pathMatch: 'full', canActivate: [AuthguardService], data: { roles: [Role.Administrador] }*/ },
      { path: 'managmentcompeticion', component: ManagementCompetitionComponent/*, pathMatch: 'full', canActivate: [AuthguardService], data: { roles: [Role.Administrador, Role.Cliente] }*/ },
      { path: 'detailscompetition/:id', component: DetailsCompetitionComponent/*, pathMatch: 'full', canActivate: [AuthguardService], data: { roles: [Role.Administrador] }*/ }
    
    ]),
    BrowserAnimationsModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ["https://localhost:8080"]
      }
    }),
  ],
  providers: [
    JwtHelperService,
    ConfirmationDialogService,
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    ServiceSettings
  ],
  bootstrap: [AppComponent],
  entryComponents: [ConfirmationDialogComponent]
})
export class AppModule { 

  constructor(private http: HttpClient, private configuration: ServiceSettings)
  {
      console.log('APP STARTING');
      this.http.get("../assets/settings.json").subscribe((res: any) => {
          configuration.baseURL = res.ServiceSettings.baseURL;
          configuration.version = res.ServiceSettings.version;
      });
  }

}
