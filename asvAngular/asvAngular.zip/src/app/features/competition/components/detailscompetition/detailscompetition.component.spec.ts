import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DetailsCompetitionComponent } from './detailscompetition.component';


describe('DetailsCompetitionComponent', () => {
  let component: DetailsCompetitionComponent;
  let fixture: ComponentFixture<DetailsCompetitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailsCompetitionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsCompetitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
