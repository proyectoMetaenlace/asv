import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Competition } from 'src/app/shared/model/competition';
import { Team } from 'src/app/shared/model/team';
import { AuthenticationService } from 'src/app/shared/services/auth/auth.service';
import { CompetitionService } from 'src/app/shared/services/competition/competition.service';
import { TeamService } from 'src/app/shared/services/team/team.service';
import { NotificationService } from 'src/app/shared/services/notification/notification.service';

@Component({
  selector: 'app-detailscompetition',
  templateUrl: './detailscompetition.component.html',
  styleUrls: ['./detailscompetition.component.css']
})
export class DetailsCompetitionComponent implements OnInit {

  action: string = "New";
  idCompetition: string;
  competition: Competition = new Competition();
  teams: Team[] = [];
  submitted = false;

  
  constructor(private route: ActivatedRoute,
    private teamService: TeamService,
    private notificationService: NotificationService,
    private competitionService: CompetitionService,
    public authService: AuthenticationService) { }

  
  ngOnInit(): void {
    
    this.idCompetition = this.route.snapshot.paramMap.get('id');
    //this.getAllTeams();
    this.getFakeTeams();
    if (this.idCompetition != "0"){
      //this.getCompetition(this.idCompetition);
      this.getFakeCompetition();
      this.action="Edit";
    } else {
      this.competition.idTeamWinner=undefined;
    }
  }

  getAllTeams() {
    this.teamService.getAllTeams().subscribe(
      data => {
        if (data) {
          console.log('la data: ' );
          this.teams = data;
        }
      }
    );
  }

  
  initCompetition(data: any) {
    if (data) {
      this.competition = data;
    }
    this.notificationService.notificationResponse(data, false)
  }

  getCompetition(id) {
    if (id) {
      this.competitionService.getCompetition(id)
        .subscribe(data => { 
          console.log(data);
          this.initCompetition(data);
        });
    }
  }

  gotoSave() {
    if (this.competition && (this.competition.name == undefined || this.competition.name == "")) {
      this.notificationService.showWarning("Alert", "The name is required");
      return;
    }
    else if (this.competition && (this.competition.yearCompetition == undefined)) {
      this.notificationService.showWarning("Alert", "The year is required");
      return;
    }
    else if (this.competition && (this.competition.type == undefined || this.competition.type == "")) {
      this.notificationService.showWarning("Alert", "The type of competition is required");
      return;
    }
    else {
      if (this.idCompetition == "0") {
        switch (this.competition.type) {
          case "journey":
            this.competitionService.createDayCompetition(this.competition)
              .subscribe(data => {
                if (data) {
                  this.notificationService.showSuccess("Action completed", "The competition has been created successfully");
                  this.competition = new Competition;
                } else {
                  this.notificationService.notificationResponse(data);
                }
              });
          break;
          case "playoff":
            this.competitionService.createKnockoutCompetition(this.competition)
            .subscribe(data => {
              if (data) {
                this.notificationService.showSuccess("Action completed", "The competition has been created successfully");
                this.competition = new Competition;
              } else {
                this.notificationService.notificationResponse(data);
              }
            });
          break;
          case "journeyPlayoff":
            this.competitionService.createDayKnockoutCompetition(this.competition)
            .subscribe(data => {
              if (data) {
                this.notificationService.showSuccess("Action completed", "The competition has been created successfully");
                this.competition = new Competition;
              } else {
                this.notificationService.notificationResponse(data);
              }
            });
          break;
        }
        
      }
      else {
        switch (this.competition.type) {
          case "journey":
            this.competitionService.updateDayCompetition(this.competition)
            .subscribe(data => {
              if (data) {
                this.notificationService.showSuccess("Action completed", "The competition has been edited correctly");
              } else {
                this.notificationService.notificationResponse(data);
              }
            });
          break;
          case "playoff":
            this.competitionService.updateKnockoutCompetition(this.competition)
            .subscribe(data => {
              if (data) {
                this.notificationService.showSuccess("Action completed", "The competition has been edited correctly");
              } else {
                this.notificationService.notificationResponse(data);
              }
            });
          break;
          case "journeyPlayoff":
            this.competitionService.updateDayKnockoutCompetition(this.competition)
            .subscribe(data => {
              if (data) {
                this.notificationService.showSuccess("Action completed", "The competition has been edited correctly");
              } else {
                this.notificationService.notificationResponse(data);
              }
            });
          break;
        }

      }
    }
  }

  radioChange(event) {
    this.competition.type = event.value;
  }


  getFakeTeams(){
    let team = new Team();
    team.id=1
    team.country = "Spain";
    team.idHistoricalRivalTeam = "Barcelona FC";
    team.name = "Real Madrid FC";
    team.shieldPhoto = "FOTO";
    let team2 = new Team();
    team2.id = 2
    team2.country = "Spain";
    team2.idHistoricalRivalTeam = "Real Madrid FC";
    team2.name = "Barcelona FC";
    team2.shieldPhoto = "FOTO2";
    this.teams.push(team, team2);
  }

  getFakeCompetition(){
    let competition = new Competition();
    competition.name = "La Liga Santander"
    competition.type = "Anual"
    competition.idTeamWinner = 1;
    competition.yearCompetition = 2020;
    this.competition = competition;

  }

}
