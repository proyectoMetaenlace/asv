import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ManagementCompetitionComponent } from './managementcompetition.component';


describe('ManagementCompetitionComponent', () => {
  let component: ManagementCompetitionComponent;
  let fixture: ComponentFixture<ManagementCompetitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagementCompetitionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagementCompetitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
