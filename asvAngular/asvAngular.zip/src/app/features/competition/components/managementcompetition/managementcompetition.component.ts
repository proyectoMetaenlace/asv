import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Competition } from 'src/app/shared/model/competition';
import { AuthenticationService } from 'src/app/shared/services/auth/auth.service';
import { PaginationService } from 'src/app/shared/services/base/pagination.service';
import { CompetitionService } from 'src/app/shared/services/competition/competition.service';
import { ConfirmationDialogService } from 'src/app/shared/services/confirmation-dialog/confirmation-dialog.service';
import { NotificationService } from 'src/app/shared/services/notification/notification.service';
import { SearchCompetition } from '../../../../shared/model/filter/searchCompetition';

@Component({
  selector: 'app-managementcompetition',
  templateUrl: './managementcompetition.component.html',
  styleUrls: ['./managementcompetition.component.css']
})
export class ManagementCompetitionComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  displayedColumns = ['name', 'yearCompetition', 'idTeamWinner'];
  
  param: SearchCompetition = new SearchCompetition;
  competitionSelect = new Array();
  dataSource: MatTableDataSource<Competition>;
  isLoading: boolean;
  totalCount: number;

  constructor(private competicionService: CompetitionService,
    private router: Router,
    public paginationService: PaginationService,
    private notificationService: NotificationService,
    private confirmationDialogService: ConfirmationDialogService,
    public authService: AuthenticationService) { 
      //this.isLoading = true;
    }

  ngOnInit(): void {
    this.param.name = "";
    this.param.year = undefined;
    this.param.winnerTeam = "";
    //this.getAllCompeticiones();
    this.getFakeCompetitions();
  }

  initDatasource(data: any) {
    if (data) {
      this.isLoading = false;
      this.dataSource = new MatTableDataSource(data);
    }
    this.notificationService.notificationResponse(data, false);

  }

  getAllCompeticiones() {
    this.competicionService.getAllCompetitions().subscribe(
      data => {
        if (data) {
          console.log(data);
          this.isLoading = false;
          this.totalCount = data.length;
          this.initDatasource(data);
          this.competitionSelect = new Array();
        }
        else {
          this.isLoading = false;
          this.notificationService.showError("Error", (data.body as any).message);
        }
      }
    );
  }

  onSearch() {
    this.dataSource = new MatTableDataSource();
    this.isLoading = true;
    this.competitionSelect = new Array();
    for (let i = 0; i < this.competitionSelect.length; i++) {
      const element = this.competitionSelect[i];
      element.highlighted = undefined;
    }
    //this.camionservice.prepareSearchFilter(this.param);
    //this.getAllCamiones();
  }

  onClearSearch() {
    this.param = new SearchCompetition;
    this.param.name = "";
    this.param.year = undefined;
    this.param.winnerTeam = "";
    this.onSearch();
    this.notificationService.showSuccess('Action completed', 'The filters have been cleaned.');
   }

  gotoCreate(){
    this.router.navigate(['/detallecompeticion/0']);
  }

  gotoEdit(){
    if (this.competitionSelect.length == 1) {
      this.router.navigate(['/detallecompeticion', this.competitionSelect[0].id ]);
    }
    else if (this.competitionSelect.length == 0) {
      this.notificationService.showWarning("Alert", "You must select a competition to edit.");
    } else {
      this.notificationService.showWarning("Alert", "You must select only one competition to edit.");
    }
  }

  onDelete() {   

    if (this.competitionSelect.length > 0) {
      var mensaje = "";
      if (this.competitionSelect.length == 1) {        
        mensaje = 'Do you want to delete the selected competition?';
      } else {
        mensaje = 'Do you want to delete the  ' + this.competitionSelect.length + ' selected competitions?';
      }
      this.confirmationDialogService.confirm('Please, confirm elimination', mensaje)
        .then((confirmed) => {
          if (confirmed) {
            var ids = new Array();
            var validadas = 0;
            for (let i = 0; i < this.competitionSelect.length; i++) {
              const element = this.competitionSelect[i];
                ids.push(element.id);
            }

            /*this.equipoService.deleteEquipo(ids)
              .subscribe(data => {
                if ((data as any).status == 0) {
                  if ((data as any).metaData.ok > 0) {
                    this.notificationService.showSuccess("Action completed", "Se han eliminado " + (data as any).metaData.ok + " de " + this.competicionesSeleccionadas.length + " equipos correctamente");
                  }
                  if ((data as any).metaData.ko > 0) {
                    this.notificationService.showWarning("Alert", "No se han podido eliminar " + (data as any).metaData.ko + " de " + this.competicionesSeleccionadas.length + " equipos seleccionados");
                  }
                }
                else {
                  this.notificationService.notificationResponse(data);
                }
                this.getAllEquipos();
                this.competicionesSeleccionadas = new Array();
              });            */
          }
        })
        .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
    } else if (this.competitionSelect.length == 0) {
      this.notificationService.showWarning("Alert", "You must select a competition to eliminate");
    }
  }

  highlight(row) {
    for (let i = 0; i < this.competitionSelect.length; i++) {
      const element = this.competitionSelect[i];
      if (element.id == row.id) {
        this.competitionSelect.splice(i, 1);
        row.highlighted = !row.highlighted;

        return;
      }
    }
    this.competitionSelect.push(row);
    row.highlighted = !row.highlighted;
    console.log(this.competitionSelect);
  }


  getFakeCompetitions(){
    let competitions = new Array<Competition>();
    let competition = new Competition();
    competition.id = 1;
    competition.idTeamWinner = 1;
    competition.name = "La liga";
    competition.yearCompetition = 2020;
    let competition2 = new Competition();
    competition2.id = 2;
    competition2.idTeamWinner = 6;
    competition2.name = "Premier League";
    competition2.yearCompetition = 2020;
    competitions.push(competition, competition2);
    this.totalCount = competitions.length;
    this.initDatasource(competitions);
    this.competitionSelect = new Array();

  }

}
