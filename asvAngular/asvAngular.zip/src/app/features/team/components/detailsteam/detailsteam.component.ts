import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Team } from 'src/app/shared/model/team';
import { AuthenticationService } from 'src/app/shared/services/auth/auth.service';
import { TeamService } from 'src/app/shared/services/team/team.service';
import { NotificationService } from 'src/app/shared/services/notification/notification.service';


@Component({
  selector: 'app-detailsteam',
  templateUrl: './detailsteam.component.html',
  styleUrls: ['./detailsteam.component.css']
})
export class DetailsTeamComponent implements OnInit {
  action: string = "New";
  idTeam: string;
  team: Team = new Team();
  teams: Team[] = [];
  registerForm: FormGroup;
  submitted = false;

  constructor(private route: ActivatedRoute,
    private equipoService: TeamService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    public authService: AuthenticationService) { }

  ngOnInit(): void {

    this.idTeam = this.route.snapshot.paramMap.get('id');
    //this.getAllTeams();
    this.getFakeTeams();
    if (this.idTeam != "0"){
      //this.getTeam(this.idTeam);
      this.getFakeTeam();
      this.action="Edit";
    } else{
      this.team.idHistoricalRivalTeam=undefined;
    }
  }

  getAllTeams() {
    this.equipoService.getAllTeams().subscribe(
      data => {
        if (data) {
          console.log('la data: ' );
          this.teams = data;
        }
      }
    );
  }

  initTeam(data: any) {
    if (data) {
      this.team = data;
    }
    this.notificationService.notificationResponse(data, false)
  }

  getTeam(id) {
    if (id) {
      this.equipoService.getTeam(id)
        .subscribe(data => { 
          console.log(data);
          this.initTeam(data);
        });
    }
  }

  gotoSave() {
    if (this.team && (this.team.name == undefined || this.team.name == "")) {
      this.notificationService.showWarning("Alert", "The name is required");
      return;
    }
    else if (this.team && (this.team.country == undefined || this.team.country == "")) {
      this.notificationService.showWarning("Alert", "The country is required");
      return;
    }
    else {
      if (this.idTeam == "0") {
        this.equipoService.createTeam(this.team)
          .subscribe(data => {
            if (data) {
              this.notificationService.showSuccess("Action completed", "The team has been successfully created");
              this.team = new Team;
            } else {
              this.notificationService.notificationResponse(data);
            }
          });
      }
      else {
        this.equipoService.updateTeam(this.team)
          .subscribe(data => {
            if (data) {
              this.notificationService.showSuccess("Action completed", "The team has been successfully edited");
            } else {
              this.notificationService.notificationResponse(data);
            }
          });
      }
    }
  }

  get f() { return this.registerForm.controls; }

  getFakeTeams(){
    let team = new Team();
    team.id=1
    team.country = "Spain";
    team.idHistoricalRivalTeam = "Barcelona FC";
    team.name = "Real Madrid FC";
    team.shieldPhoto = "FOTO";
    let team2 = new Team();
    team2.id = 2
    team2.country = "Spain";
    team2.idHistoricalRivalTeam = "Real Madrid FC";
    team2.name = "Barcelona FC";
    team2.shieldPhoto = "FOTO2";
    this.teams.push(team, team2);
  }

  getFakeTeam(){
    let team = new Team();
    team.id=1
    team.country = "Spain";
    team.idHistoricalRivalTeam = "2";
    team.name = "Real Madrid FC";
    team.shieldPhoto = "FOTO";
    this.initTeam(team);

  }

}
