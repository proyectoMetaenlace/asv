import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Team } from 'src/app/shared/model/team';
import { AuthenticationService } from 'src/app/shared/services/auth/auth.service';
import { PaginationService } from 'src/app/shared/services/base/pagination.service';
import { ConfirmationDialogService } from 'src/app/shared/services/confirmation-dialog/confirmation-dialog.service';
import { TeamService } from 'src/app/shared/services/team/team.service';
import { NotificationService } from 'src/app/shared/services/notification/notification.service';

import { SearchTeam } from '../../../../shared/model/filter/searchTeam';

@Component({
  selector: 'app-managementteam',
  templateUrl: './managementteam.component.html',
  styleUrls: ['./managementteam.component.css']
})
export class ManagementTeamComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  displayedColumns = ['shieldPhoto', 'name', 'country', 'historicalRivalTeam'];
  
  param: SearchTeam = new SearchTeam;
  teamsSelected = new Array();
  dataSource: MatTableDataSource<Team>;
  isLoading: boolean;
  totalCount: number;

  constructor(private equipoService: TeamService,
    private router: Router,
    public paginationService: PaginationService,
    private notificationService: NotificationService,
    private confirmationDialogService: ConfirmationDialogService,
    public authService: AuthenticationService) { 
      //this.isLoading = true;
    }

  ngOnInit(): void {
    this.param.name = "";
    this.param.country = "";
    this.param.historialRivalTeam = "";
    //this.getAllTeams();
    this.getFakeTeams();
  }

  initDatasource(data: any) {
    if (data) {
      this.isLoading = false;
      this.dataSource = new MatTableDataSource(data);
    }
    this.notificationService.notificationResponse(data, false);

  }

  getAllTeams() {
    this.equipoService.getAllTeams().subscribe(
      data => {
        if (data) {
          console.log(data);
          this.isLoading = false;
          this.totalCount = data.length;
          this.initDatasource(data);
          this.teamsSelected = new Array();
        }
        else {
          this.isLoading = false;
          this.notificationService.showError("Error", (data.body as any).message);
        }
      }
    );
  }

  onSearch() {
    this.dataSource = new MatTableDataSource();
    this.isLoading = true;
    this.teamsSelected = new Array();
    for (let i = 0; i < this.teamsSelected.length; i++) {
      const element = this.teamsSelected[i];
      element.highlighted = undefined;
    }
    //this.camionservice.prepareSearchFilter(this.param);
    //this.getAllCamiones();
  }

  onClearSearch() {
    this.param = new SearchTeam;
    this.param.name = "";
    this.param.country = "";
    this.param.historialRivalTeam = "";
    this.onSearch();
    this.notificationService.showSuccess('Action completed', 'The filters have been cleaned.');
   }

  gotoCreate(){
    this.router.navigate(['/detalleequipo/0']);
  }

  gotoEdit(){
    if (this.teamsSelected.length == 1) {
      this.router.navigate(['/detailsteam', this.teamsSelected[0].id ]);
    }
    else if (this.teamsSelected.length == 0) {
      this.notificationService.showWarning("Alert", "You must select a team to edit.");
    } else {
      this.notificationService.showWarning("Alert", "You must select only one team to edit.");
    }
  }

  onDelete() {   

    if (this.teamsSelected.length > 0) {
      var mensaje = "";
      if (this.teamsSelected.length == 1) {        
        mensaje = 'Do you want to delete the selected team?';
      } else {
        mensaje = 'Do you want to delete the ' + this.teamsSelected.length + ' selected teams?';
      }
      this.confirmationDialogService.confirm('Please, confirm elimination', mensaje)
        .then((confirmed) => {
          if (confirmed) {
            var ids = new Array();
            var validadas = 0;
            for (let i = 0; i < this.teamsSelected.length; i++) {
              const element = this.teamsSelected[i];
                ids.push(element.id);
            }

            /*this.equipoService.deleteEquipo(ids)
              .subscribe(data => {
                if ((data as any).status == 0) {
                  if ((data as any).metaData.ok > 0) {
                    this.notificationService.showSuccess("Action completed", "Se han eliminado " + (data as any).metaData.ok + " de " + this.teamsSelected.length + " equipos correctamente");
                  }
                  if ((data as any).metaData.ko > 0) {
                    this.notificationService.showWarning("Alert", "No se han podido eliminar " + (data as any).metaData.ko + " de " + this.teamsSelected.length + " equipos seleccionados");
                  }
                }
                else {
                  this.notificationService.notificationResponse(data);
                }
                this.getAllEquipos();
                this.teamsSelected = new Array();
              });            */
          }
        })
        .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
    } else if (this.teamsSelected.length == 0) {
      this.notificationService.showWarning("Alert", "You must select a team to remove");
    }
  }

  highlight(row) {
    for (let i = 0; i < this.teamsSelected.length; i++) {
      const element = this.teamsSelected[i];
      if (element.id == row.id) {
        this.teamsSelected.splice(i, 1);
        row.highlighted = !row.highlighted;

        return;
      }
    }
    this.teamsSelected.push(row);
    row.highlighted = !row.highlighted;
    console.log(this.teamsSelected);
  }


  getFakeTeams(){
    let teams = new Array<Team>();
    let team = new Team();
    team.id=1
    team.country = "Spain";
    team.idHistoricalRivalTeam = "Barcelona FC";
    team.name = "Real Madrid FC";
    team.shieldPhoto = "FOTO";
    let team2 = new Team();
    team2.id = 2
    team2.country = "Spain";
    team2.idHistoricalRivalTeam = "Real Madrid FC";
    team2.name = "Barcelona FC";
    team2.shieldPhoto = "FOTO2";
    teams.push(team, team2)
    this.totalCount = teams.length;
    this.initDatasource(teams);
    this.teamsSelected = new Array();
  }

}
