import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class ServiceSettings {

    public baseURL: string;
    public version: string;
    public idle: number;
    public static get URLSeparator(): string { return "/"; }


    constructor(private httpClient: Http) { }

    async load() : Promise<any>{
        const promise = this.httpClient.get(window.location.origin + '/api/ServiceSettings')
            .toPromise()
            .then(settings => {
                return settings;
            });

        return promise;
    }
}
