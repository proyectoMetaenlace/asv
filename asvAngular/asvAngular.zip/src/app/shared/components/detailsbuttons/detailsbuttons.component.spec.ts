import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsButtonsComponent } from './detailsbuttons.component';

describe('DetailsButtonsComponent', () => {
  let component: DetailsButtonsComponent;
  let fixture: ComponentFixture<DetailsButtonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailsButtonsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsButtonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
