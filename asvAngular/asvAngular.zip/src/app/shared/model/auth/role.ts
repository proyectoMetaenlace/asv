export enum Role {
    Administrador = 'Administrador',
    Cliente = 'Cliente'
}