export class Competition {
    id: number;
    name: string;  
    yearCompetition: number;
    idTeamWinner: number; 
    type: string;
}