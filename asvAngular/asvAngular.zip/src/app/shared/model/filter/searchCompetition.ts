export class SearchCompetition {   
    name: string;
    year: number;
    winnerTeam: string;
}