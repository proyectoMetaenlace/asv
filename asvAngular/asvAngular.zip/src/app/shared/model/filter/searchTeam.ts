export class SearchTeam {   
    name: string;
    country: string;
    historialRivalTeam: string;
}