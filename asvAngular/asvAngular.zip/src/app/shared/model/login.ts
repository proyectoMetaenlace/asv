export class LoginModel {
    id: number;
    firstName: string;
    lastName: string;
    username: string;
    password: string;
    role: string;
    refreshToken: string;
    token: string;
}