export class Person {
    id: number;
    login: string;
    password: string;
    nombre: string;
    firstSurname: string;
    secondSurname: string;
    email: string;
    dateBirth: Date;
    telephone: string;
}