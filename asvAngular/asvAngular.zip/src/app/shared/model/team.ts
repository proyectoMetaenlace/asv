export class Team {
    id: number;
    name: string;  
    country: string;
    idHistoricalRivalTeam: string;
    shieldPhoto: string;  
}