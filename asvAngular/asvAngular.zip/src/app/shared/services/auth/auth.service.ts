import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { ServiceSettings } from 'src/app/service-settings'
import { JwtHelperService } from '@auth0/angular-jwt';
import { User } from '../../model/auth/user';
import { LoginDTO, RegistroDTO } from '../../model/auth/login';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;
    

    constructor(private http: HttpClient,
        private settings: ServiceSettings,
        private jwtHelper: JwtHelperService) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(sessionStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    public get currentUserId(){
        return this.currentUserSubject.value.id;
    }

    public getAuthorizationToken() {
        if (this.currentUserValue && this.currentUserValue.token)
            return this.currentUserValue.token;
        return "";
    }

    login(username: string, password: string) {
        var loginDTO : LoginDTO = new LoginDTO();
        loginDTO.username = username;
        loginDTO.password = password;
        return this.http.post<any>('http://localhost:4200/target/api/login/', { loginDTO })
        .pipe(map(user => {
        return user;
        if (user && user.token) {
          sessionStorage.setItem('currentUser', JSON.stringify(user));
          this.currentUserSubject.next(user);
        }

        return user;
      }));
    }

    logout() {
        sessionStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
    }


    isLoggedIn() {
        let user = this.currentUserValue;
        if (user && user.token) {
        return true;
        }
        return false;
    }


    isLoggedInExpiration() {
        let user = this.currentUserValue;
        if (user && user.token && !this.jwtHelper.isTokenExpired(user.token)) {
            return true;
        }
        return false;
    }

    isExpirado() {
        let user = this.currentUserValue;
        let result = this.jwtHelper.isTokenExpired(user.token);
        return result; 
    }

    public get isAdmin(){
            let user = this.currentUserValue;
            if (user && user.role && user.role == "Administrador") {
                return true;
            }
            return false;
    }

    public registrar(username: string, password: string, email: string) {
        var registroDTO : RegistroDTO = new RegistroDTO();
        registroDTO.username = username;
        registroDTO.password = password;
        registroDTO.email = email;
        return this.http.post<any>('http://localhost:4200/target/api/usuarios/', { username, password, email });
    }
}
