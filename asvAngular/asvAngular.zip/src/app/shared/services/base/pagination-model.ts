export class PaginationModel {
    selectItemsPerPage: number[] = [5, 10, 25, 50, 100];
    pageSize = 50;
    pageIndex = 1;
    allItemsLength = 0;
}
